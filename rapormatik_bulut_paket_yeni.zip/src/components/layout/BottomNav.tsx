'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, CalendarDays, PlusCircle, Building2, Settings } from 'lucide-react';

export default function BottomNav() {
  const pathname = usePathname();

  const navItems = [
    { name: 'Ana Sayfa', href: '/', icon: Home },
    { name: 'İşletmeler', href: '/workplaces', icon: Building2 },
    { name: 'Yeni', href: '/inspections/new', icon: PlusCircle, isMain: true },
    { name: 'Takvim', href: '/calendar', icon: CalendarDays },
    { name: 'Ayarlar', href: '/settings', icon: Settings },
  ];

  return (
    <div className="fixed bottom-0 left-0 w-full bg-white border-t border-gray-200 pb-safe z-50">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;

          if (item.isMain) {
            return (
              <Link key={item.name} href={item.href} className="relative -top-5">
                <div className="bg-blue-600 text-white p-4 rounded-full shadow-lg flex items-center justify-center border-4 border-white">
                  <Icon className="w-8 h-8" />
                </div>
              </Link>
            );
          }

          return (
            <Link
              key={item.name}
              href={item.href}
              className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
                isActive ? 'text-blue-600' : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              <Icon className="w-6 h-6" />
              <span className="text-[10px] font-medium">{item.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
