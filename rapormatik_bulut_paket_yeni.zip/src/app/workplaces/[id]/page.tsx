'use client';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/lib/db/offline';
import { 
  ChevronLeft, Building2, MapPin, User, Phone, 
  Calendar, Plus, Clock, CheckCircle2, AlertCircle, X,
  ChevronRight
} from 'lucide-react';
import Link from 'next/link';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';

export default function WorkplaceDetail() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const workplace = useLiveQuery(() => db.workplaces.get(id));
  const inspections = useLiveQuery(() => 
    db.inspections.where('workplaceId').equals(id).reverse().toArray()
  ) || [];

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [scheduledDate, setScheduledDate] = useState(format(new Date(), "yyyy-MM-dd'T'HH:mm"));

  const handleScheduleInspection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scheduledDate) return;

    const newInspectionId = crypto.randomUUID();
    await db.inspections.add({
      id: newInspectionId,
      workplaceId: id,
      date: new Date(scheduledDate).toISOString(),
      status: 'Planned',
      inspector: 'JD', // Default or from auth
      synced: false
    });

    setIsModalOpen(false);
    toast.success('Yeni denetim randevusu oluşturuldu');
  };

  if (!workplace) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  return (
    <div className="bg-gray-50 min-h-screen pb-24">
      {/* Header */}
      <header className="bg-white p-4 pt-6 shadow-sm border-b border-gray-100 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <Link href="/workplaces" className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </Link>
          <h1 className="text-xl font-bold text-gray-900 leading-tight">İşletme Detayı</h1>
        </div>
      </header>

      <div className="p-4 space-y-6">
        {/* Workplace Info Card */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 border border-blue-100 shadow-inner">
              <Building2 className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{workplace.name}</h2>
              <p className="text-sm text-gray-500 font-medium">{workplace.authorizedPerson}</p>
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-gray-50">
            <div className="flex items-start gap-3">
              <div className="mt-1 p-2 bg-gray-50 rounded-lg">
                <MapPin className="w-4 h-4 text-gray-400" />
              </div>
              <div className="flex-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Adres</p>
                <p className="text-sm text-gray-700 leading-relaxed">{workplace.address}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="mt-1 p-2 bg-gray-50 rounded-lg">
                <Phone className="w-4 h-4 text-gray-400" />
              </div>
              <div className="flex-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Telefon</p>
                <p className="text-sm text-gray-700">{workplace.phone}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Inspections Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-gray-400" />
              Denetim Kayıtları
            </h3>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 hover:bg-blue-700 shadow-md shadow-blue-100 transition-all active:scale-95"
            >
              <Plus className="w-4 h-4" />
              Randevu Oluştur
            </button>
          </div>

          <div className="space-y-3">
            {inspections.map(inspection => (
              <div key={inspection.id} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center justify-between group hover:border-blue-100 transition-all">
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-xl ${
                    inspection.status === 'Completed' ? 'bg-green-50 text-green-600' :
                    inspection.status === 'Planned' ? 'bg-yellow-50 text-yellow-600' : 'bg-red-50 text-red-600'
                  }`}>
                    {inspection.status === 'Completed' ? <CheckCircle2 className="w-5 h-5" /> :
                     inspection.status === 'Planned' ? <Clock className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-900">
                      {format(new Date(inspection.date), 'dd MMMM yyyy', { locale: tr })}
                    </p>
                    <p className="text-[10px] font-semibold uppercase text-gray-400">
                      {inspection.status === 'Planned' ? 'Planlanan' : 
                       inspection.status === 'Completed' ? 'Tamamlanan' : 'Takip Gereken'}
                    </p>
                  </div>
                </div>
                <Link 
                  href={`/inspections/${inspection.id}`}
                  className="p-2 bg-gray-50 rounded-lg text-gray-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-all"
                >
                  <ChevronRight className="w-5 h-5" />
                </Link>
              </div>
            ))}
            {inspections.length === 0 && (
              <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-gray-200">
                <Calendar className="w-12 h-12 text-gray-100 mx-auto mb-3" />
                <p className="text-gray-400 font-medium">Henüz denetim kaydı bulunmuyor.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Schedule Inspection Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
              <h2 className="text-xl font-bold text-gray-900">Randevu Oluştur</h2>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-200 rounded-full transition-colors text-gray-500">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleScheduleInspection} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase ml-1">Denetim Tarihi ve Saati</label>
                <input 
                  type="datetime-local" 
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  autoFocus
                />
              </div>
              <button 
                type="submit"
                className="w-full py-4 bg-blue-600 text-white font-bold rounded-2xl shadow-lg shadow-blue-200 hover:bg-blue-700 active:scale-[0.98] transition-all mt-2"
              >
                Randevuyu Kaydet
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
