'use client';

import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/lib/db/offline';
import Link from 'next/link';
import { Building2, Search, MapPin, ChevronRight, Plus, X, User, Phone } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Workplaces() {
  const workplaces = useLiveQuery(() => db.workplaces.toArray()) || [];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newAddress, setNewAddress] = useState('');
  const [newAuthorizedPerson, setNewAuthorizedPerson] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newAddress || !newAuthorizedPerson || !newPhone) {
      toast.error('Lütfen tüm alanları doldurun');
      return;
    }

    const newId = crypto.randomUUID();
    await db.workplaces.add({
      id: newId,
      name: newName,
      address: newAddress,
      authorizedPerson: newAuthorizedPerson,
      phone: newPhone,
      synced: false
    });

    setNewName('');
    setNewAddress('');
    setNewAuthorizedPerson('');
    setNewPhone('');
    setIsModalOpen(false);
    toast.success('İşletme başarıyla eklendi');
  };

  const filteredWorkplaces = workplaces.filter(w => 
    w.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    w.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    w.authorizedPerson?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 min-h-screen pb-24 bg-gray-50">
      <header className="pt-4 pb-2 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">İşletmeler</h1>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700 transition active:scale-95"
        >
          <Plus className="w-6 h-6" />
        </button>
      </header>

      {/* Search Bar */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-xl leading-5 bg-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 sm:text-sm shadow-sm transition-all"
          placeholder="İşletme, adres veya yetkili ara..."
        />
      </div>

      <div className="space-y-3">
        {filteredWorkplaces.map(workplace => (
          <div key={workplace.id} className="bg-white border border-gray-100 p-4 rounded-2xl shadow-sm flex items-center justify-between group hover:border-blue-100 transition-colors">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 border border-blue-100">
                <Building2 className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-gray-900 group-hover:text-blue-700 transition-colors">{workplace.name}</h3>
                <div className="flex flex-col gap-0.5 mt-1">
                  <div className="flex items-center text-[10px] text-gray-500 space-x-1">
                    <User className="w-3 h-3" />
                    <span className="font-medium text-gray-700">{workplace.authorizedPerson}</span>
                  </div>
                  <div className="flex items-center text-[10px] text-gray-400 space-x-1">
                    <MapPin className="w-3 h-3" />
                    <span className="truncate max-w-[180px]">{workplace.address}</span>
                  </div>
                </div>
              </div>
            </div>
            <Link href={`/workplaces/${workplace.id}`} className="p-2 bg-gray-50 rounded-lg text-gray-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-all">
              <ChevronRight className="w-5 h-5" />
            </Link>
          </div>
        ))}
        {filteredWorkplaces.length === 0 && (
          <div className="text-center py-12 text-gray-400 bg-white rounded-3xl border border-dashed border-gray-200 flex flex-col items-center gap-3">
            <Building2 className="w-12 h-12 text-gray-200" />
            <p className="font-medium">{searchTerm ? 'Arama sonucu bulunamadı' : 'Henüz işletme eklenmemiş'}</p>
          </div>
        )}
      </div>

      {/* Add Workplace Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
              <h2 className="text-xl font-bold text-gray-900">Yeni İşletme Ekle</h2>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-200 rounded-full transition-colors text-gray-500">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase ml-1 tracking-wider">İşletme Adı</label>
                <input 
                  type="text" 
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all text-sm"
                  placeholder="Örn: Lezzetli Fırın"
                  autoFocus
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500 uppercase ml-1 tracking-wider">Yetkili Kişi</label>
                  <input 
                    type="text" 
                    value={newAuthorizedPerson}
                    onChange={(e) => setNewAuthorizedPerson(e.target.value)}
                    className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all text-sm"
                    placeholder="Ad Soyad"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500 uppercase ml-1 tracking-wider">Telefon</label>
                  <input 
                    type="tel" 
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all text-sm"
                    placeholder="05..."
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase ml-1 tracking-wider">Adres</label>
                <textarea 
                  value={newAddress}
                  onChange={(e) => setNewAddress(e.target.value)}
                  className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all min-h-[80px] text-sm"
                  placeholder="İşletmenin tam adresi..."
                />
              </div>
              <button 
                type="submit"
                className="w-full py-4 bg-blue-600 text-white font-bold rounded-2xl shadow-lg shadow-blue-200 hover:bg-blue-700 active:scale-[0.98] transition-all mt-2"
              >
                İşletmeyi Kaydet
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
