'use client';

import { useState, Suspense } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/lib/db/offline';
import { useRouter, useSearchParams } from 'next/navigation';
import { Check, ArrowRight, Building2, User, Calendar as CalendarIcon } from 'lucide-react';
import toast from 'react-hot-toast';

function NewInspectionContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const preselectedDate = searchParams.get('date');
  
  const workplaces = useLiveQuery(() => db.workplaces.toArray()) || [];
  
  const [selectedWorkplace, setSelectedWorkplace] = useState<string>('');
  const [inspector, setInspector] = useState('John Doe'); // Default for demo

  const handleStart = async () => {
    if (!selectedWorkplace) {
      toast.error('Lütfen bir işletme seçin');
      return;
    }

    const newId = crypto.randomUUID();
    const inspectionDate = preselectedDate ? new Date(preselectedDate).toISOString() : new Date().toISOString();
    
    await db.inspections.add({
      id: newId,
      workplaceId: selectedWorkplace,
      date: inspectionDate,
      status: 'Planned',
      inspector: inspector,
      synced: false,
    });

    toast.success('Denetim Başlatıldı');
    router.push(`/inspections/${newId}`);
  };

  return (
    <div className="p-4 space-y-6 animate-in fade-in slide-in-from-right-4 duration-500 min-h-screen bg-gray-50">
      <header className="pt-4 pb-2 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Yeni Denetim</h1>
        <p className="text-sm text-gray-500">Yeni bir ziyaret planlayın veya hemen başlatın</p>
      </header>

      <div className="space-y-6">
        {/* Workplace Selection */}
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-500" />
            İşletme Seç
          </label>
          <select 
            value={selectedWorkplace}
            onChange={(e) => setSelectedWorkplace(e.target.value)}
            className="w-full p-4 bg-white border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 outline-none appearance-none font-medium"
          >
            <option value="" disabled>Bir işletme seçin...</option>
            {workplaces.map(w => (
              <option key={w.id} value={w.id}>{w.name}</option>
            ))}
          </select>
        </div>

        {/* Inspector Name */}
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
            <User className="w-4 h-4 text-blue-500" />
            Denetmen Adı
          </label>
          <input 
            type="text"
            value={inspector}
            onChange={(e) => setInspector(e.target.value)}
            className="w-full p-4 bg-white border border-gray-200 rounded-xl shadow-sm focus:ring-2 focus:ring-blue-500 outline-none font-medium"
          />
        </div>

        {/* Action Button */}
        <div className="pt-8">
          <button 
            onClick={handleStart}
            className="w-full bg-blue-600 text-white font-bold text-lg p-4 rounded-xl shadow-lg hover:bg-blue-700 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            {preselectedDate ? 'Planla' : 'Denetimi Başlat'}
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function NewInspection() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-gray-500">Yükleniyor...</div>}>
      <NewInspectionContent />
    </Suspense>
  );
}
