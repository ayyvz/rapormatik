'use client';

import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/lib/db/offline';
import Link from 'next/link';
import { AlertTriangle, Search, ChevronRight, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';

export default function FollowUpInspections() {
  const inspections = useLiveQuery(() => db.inspections.where('status').equals('Follow-up Required').toArray()) || [];
  const workplaces = useLiveQuery(() => db.workplaces.toArray()) || [];

  return (
    <div className="p-4 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24">
      <header className="pt-4 pb-2 flex items-center gap-3">
        <div className="bg-red-100 p-2 rounded-full">
          <AlertTriangle className="w-6 h-6 text-red-600" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Takip Gerekenler</h1>
      </header>

      {/* Search Bar */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-xl leading-5 bg-gray-50 placeholder-gray-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-red-500 focus:border-red-500 sm:text-sm transition-colors"
          placeholder="Ara..."
        />
      </div>

      <div className="space-y-3">
        {inspections.map(inspection => {
          const workplace = workplaces.find(w => w.id === inspection.workplaceId);
          return (
            <Link key={inspection.id} href={`/inspections/${inspection.id}`}>
              <div className="bg-white border border-gray-100 p-4 rounded-2xl shadow-sm flex items-center justify-between active:scale-[0.98] transition-transform mb-3">
                <div>
                  <h3 className="font-bold text-gray-900">{workplace?.name || 'Bilinmeyen'}</h3>
                  <div className="flex items-center text-sm text-gray-500 mt-1 space-x-2">
                    <Clock className="w-4 h-4" />
                    <span>{format(new Date(inspection.date), 'dd MMM yyyy', { locale: tr })}</span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
            </Link>
          );
        })}
        {inspections.length === 0 && (
          <div className="text-center py-8 text-gray-400 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
            Takip gerektiren denetim bulunmuyor
          </div>
        )}
      </div>
    </div>
  );
}
