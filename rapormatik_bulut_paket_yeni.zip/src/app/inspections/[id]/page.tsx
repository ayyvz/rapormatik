'use client';

import { useState, useMemo, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/lib/db/offline';
import { 
  Check, X, Camera, FileText, ChevronLeft, AlertCircle, 
  Plus, LayoutGrid, Image as ImageIcon, Trash2
} from 'lucide-react';
import toast from 'react-hot-toast';
import Link from 'next/link';

export default function InspectionDetail() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const inspection = useLiveQuery(() => db.inspections.get(id));
  const workplace = useLiveQuery(() => 
    inspection ? db.workplaces.get(inspection.workplaceId) : undefined
  , [inspection]);
  
  const allCriteria = useLiveQuery(() => db.criteria.toArray()) || [];
  const results = useLiveQuery(() => db.inspectionResults.where('inspectionId').equals(id).toArray()) || [];

  const mainTabs = useMemo(() => {
    const tabs = Array.from(new Set(allCriteria.map(c => c.mainTitle)));
    return tabs.length > 0 ? tabs : ['Hijyen', 'Güvenlik', 'Belgeler'];
  }, [allCriteria]);

  const [activeTab, setActiveTab] = useState('');
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newSubTitle, setNewSubTitle] = useState('');
  
  // Note Modal State
  const [editingNote, setEditingNote] = useState<{criteriaId: string, text: string} | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingFor, setUploadingFor] = useState<string | null>(null);

  useMemo(() => {
    if (!activeTab && mainTabs.length > 0) setActiveTab(mainTabs[0]);
    else if (activeTab && !mainTabs.includes(activeTab) && mainTabs.length > 0) setActiveTab(mainTabs[0]);
  }, [mainTabs, activeTab]);

  const criteriaList = allCriteria.filter(c => c.mainTitle === activeTab);

  const handleStatusUpdate = async (criteriaId: string, status: 'OK' | 'Needs Improvement' | 'Not Compliant') => {
    const existing = await db.inspectionResults.where({ inspectionId: id, criteriaId }).first();
    if (existing) {
      await db.inspectionResults.update(existing.id, { status });
    } else {
      await db.inspectionResults.add({
        id: crypto.randomUUID(),
        inspectionId: id,
        criteriaId,
        status,
        notes: '',
        photos: []
      });
    }
    toast.success('Durum Güncellendi');
  };

  const handleSaveNote = async () => {
    if (!editingNote) return;
    const existing = await db.inspectionResults.where({ inspectionId: id, criteriaId: editingNote.criteriaId }).first();
    if (existing) {
      await db.inspectionResults.update(existing.id, { notes: editingNote.text });
    } else {
      await db.inspectionResults.add({
        id: crypto.randomUUID(),
        inspectionId: id,
        criteriaId: editingNote.criteriaId,
        status: 'OK', // Default
        notes: editingNote.text,
        photos: []
      });
    }
    setEditingNote(null);
    toast.success('Not Kaydedildi');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !uploadingFor) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      const existing = await db.inspectionResults.where({ inspectionId: id, criteriaId: uploadingFor }).first();
      
      if (existing) {
        const newPhotos = [...(existing.photos || []), base64String];
        await db.inspectionResults.update(existing.id, { photos: newPhotos });
      } else {
        await db.inspectionResults.add({
          id: crypto.randomUUID(),
          inspectionId: id,
          criteriaId: uploadingFor,
          status: 'OK',
          notes: '',
          photos: [base64String]
        });
      }
      toast.success('Fotoğraf Eklendi');
      setUploadingFor(null);
    };
    reader.readAsDataURL(file);
  };

  const removePhoto = async (criteriaId: string, photoIndex: number) => {
    const existing = await db.inspectionResults.where({ inspectionId: id, criteriaId }).first();
    if (existing && existing.photos) {
      const newPhotos = existing.photos.filter((_, i) => i !== photoIndex);
      await db.inspectionResults.update(existing.id, { photos: newPhotos });
      toast.success('Fotoğraf Silindi');
    }
  };

  if (!inspection || !workplace) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  return (
    <div className="bg-gray-50 min-h-screen pb-40">
      {/* Hidden File Input */}
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileUpload} 
        accept="image/*" 
        className="hidden" 
      />

      {/* Header */}
      <header className="bg-white px-4 pt-6 pb-4 shadow-sm sticky top-0 z-10 border-b border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <Link href="/" className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-gray-900 leading-tight">{workplace.name}</h1>
            <div className="flex items-center gap-2 mt-0.5">
              <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                inspection.status === 'Planned' ? 'bg-blue-50 text-blue-600' : 'bg-green-50 text-green-600'
              }`}>
                {inspection.status === 'Planned' ? 'Planlandı' : 'Tamamlandı'}
              </span>
            </div>
          </div>
        </div>

        {/* Dynamic Category Tabs */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 px-1">
          {mainTabs.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === tab 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' 
                  : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </header>

      {/* Criteria List */}
      <div className="p-4 space-y-4">
        {criteriaList.map(criteria => {
          const result = results.find(r => r.criteriaId === criteria.id);
          
          return (
            <div key={criteria.id} className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100">
              <h3 className="font-bold text-gray-800 mb-4 text-lg leading-snug">{criteria.subTitle}</h3>
              
              {/* Action Buttons */}
              <div className="grid grid-cols-3 gap-3 mb-5">
                {[
                  { id: 'OK', label: 'Uygun', icon: Check, color: 'green' },
                  { id: 'Needs Improvement', label: 'Gelişmeli', icon: AlertCircle, color: 'yellow' },
                  { id: 'Not Compliant', label: 'Uygun Değil', icon: X, color: 'red' }
                ].map(opt => (
                  <button 
                    key={opt.id}
                    onClick={() => handleStatusUpdate(criteria.id, opt.id as any)}
                    className={`py-4 rounded-2xl flex flex-col items-center justify-center gap-1.5 border-2 transition-all ${
                      result?.status === opt.id 
                        ? `border-${opt.color}-500 bg-${opt.color}-50 text-${opt.color}-700 shadow-sm` 
                        : 'border-transparent bg-gray-50 text-gray-400 hover:bg-gray-100'
                    }`}
                  >
                    <opt.icon className={`w-6 h-6 ${result?.status === opt.id ? `text-${opt.color}-600` : ''}`} />
                    <span className="text-[10px] font-bold uppercase">{opt.label}</span>
                  </button>
                ))}
              </div>

              {/* Photos Preview */}
              {result?.photos && result.photos.length > 0 && (
                <div className="flex gap-2 overflow-x-auto no-scrollbar mb-4 pb-1">
                  {result.photos.map((photo, idx) => (
                    <div key={idx} className="relative flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden border border-gray-100 shadow-sm">
                      <img src={photo} alt="Denetim" className="w-full h-full object-cover" />
                      <button 
                        onClick={() => removePhoto(criteria.id, idx)}
                        className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full shadow-lg"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Note Preview */}
              {result?.notes && (
                <div className="mb-4 p-3 bg-blue-50/50 rounded-xl border border-blue-100 text-xs text-blue-800 italic leading-relaxed">
                  "{result.notes}"
                </div>
              )}

              {/* Media & Notes Controls */}
              <div className="flex gap-2 border-t border-gray-50 pt-4">
                <button 
                  onClick={() => {
                    setUploadingFor(criteria.id);
                    fileInputRef.current?.click();
                  }}
                  className="flex-1 bg-gray-50 hover:bg-gray-100 text-gray-600 py-3 rounded-xl flex items-center justify-center gap-2 text-xs font-bold transition"
                >
                  <Camera className="w-4 h-4" />
                  FOTOĞRAF
                </button>
                <button 
                  onClick={() => setEditingNote({ criteriaId: criteria.id, text: result?.notes || '' })}
                  className="flex-1 bg-gray-50 hover:bg-gray-100 text-gray-600 py-3 rounded-xl flex items-center justify-center gap-2 text-xs font-bold transition"
                >
                  <FileText className="w-4 h-4" />
                  {result?.notes ? 'NOTU DÜZENLE' : 'NOT EKLE'}
                </button>
              </div>
            </div>
          );
        })}

        {/* Empty Category View */}
        {criteriaList.length === 0 && (
          <div className="text-center py-16 text-gray-400 bg-white rounded-3xl border border-dashed border-gray-200">
            <LayoutGrid className="w-12 h-12 text-gray-200 mx-auto mb-4" />
            <p className="font-medium">{activeTab} için henüz kriter tanımlanmamış.</p>
          </div>
        )}
      </div>

      {/* Note Editing Modal */}
      {editingNote && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden p-6 space-y-4">
            <h3 className="text-lg font-bold text-gray-900">Not Ekle/Düzenle</h3>
            <textarea 
              value={editingNote.text}
              onChange={(e) => setEditingNote({ ...editingNote, text: e.target.value })}
              className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 min-h-[150px] text-sm"
              placeholder="Gözlemlerinizi buraya yazın..."
              autoFocus
            />
            <div className="flex gap-2">
              <button 
                onClick={handleSaveNote}
                className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-blue-700 transition"
              >
                Kaydet
              </button>
              <button 
                onClick={() => setEditingNote(null)}
                className="px-6 bg-white text-gray-500 font-bold py-3 rounded-xl border border-gray-200 hover:bg-gray-100 transition"
              >
                Vazgeç
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Complete Button */}
      <div className="fixed bottom-0 left-0 w-full p-4 bg-white/80 backdrop-blur-md border-t border-gray-100 shadow-xl z-20">
        <div className="max-w-md mx-auto">
          <button 
            className="w-full bg-gray-900 text-white font-bold text-lg p-5 rounded-2xl shadow-xl hover:bg-black active:scale-[0.98] transition-all"
            onClick={async (e) => {
              const btn = e.currentTarget;
              btn.disabled = true;
              btn.innerText = 'Rapor Oluşturuluyor...';
              
              try {
                const { jsPDF } = await import('jspdf');
                const doc = new jsPDF();
                
                doc.setFontSize(18);
                doc.text(`DENETIM RAPORU: ${workplace.name}`, 20, 20);
                
                let yPos = 30;
                results.forEach(res => {
                  const crit = allCriteria.find(c => c.id === res.criteriaId);
                  if (crit) {
                    if (yPos > 270) { doc.addPage(); yPos = 20; }
                    doc.setFontSize(11);
                    doc.text(`${crit.subTitle}: ${res.status}`, 20, yPos);
                    if (res.notes) {
                      yPos += 5;
                      doc.setFontSize(9);
                      doc.setTextColor(100);
                      doc.text(`Not: ${res.notes}`, 25, yPos);
                      doc.setTextColor(0);
                    }
                    yPos += 10;
                  }
                });

                await db.inspections.update(id, { status: 'Completed' });
                toast.success('Denetim Tamamlandı!');
                router.push('/');
              } catch (e) {
                toast.error('Hata oluştu!');
                btn.disabled = false;
                btn.innerText = 'Denetimi Tamamla';
              }
            }}
          >
            Denetimi Tamamla
          </button>
        </div>
      </div>
    </div>
  );
}
