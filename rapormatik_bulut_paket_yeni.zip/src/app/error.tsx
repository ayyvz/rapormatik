'use client';

export default function ErrorBoundary({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div className="p-8 text-center text-red-500">
      <h2 className="font-bold text-xl mb-4">Bir Hata Oluştu!</h2>
      <p className="text-sm bg-red-50 p-4 rounded-xl font-mono text-left overflow-auto">{error.message}</p>
      <button 
        onClick={() => reset()}
        className="mt-6 px-4 py-2 bg-red-600 text-white rounded-lg"
      >
        Tekrar Dene
      </button>
    </div>
  );
}
