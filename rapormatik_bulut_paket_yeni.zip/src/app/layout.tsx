import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import BottomNav from "@/components/layout/BottomNav";
import { Toaster } from "react-hot-toast";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Rapormatik",
  description: "Inspection Report Management Application",
};

export const viewport: Viewport = {
  themeColor: "#2563eb",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr">
      <body className={inter.className} style={{ backgroundColor: '#f9fafb', margin: 0, padding: 0 }}>
        <div className="max-w-md mx-auto min-h-screen bg-white shadow-xl relative pb-20">
          <Toaster position="top-center" />
          {children}
          <BottomNav />
        </div>
      </body>
    </html>
  );
}
