'use client';

import { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/lib/db/offline';
import { 
  ChevronLeft, Plus, Trash2, LayoutGrid, ListTree, 
  FolderPlus, FolderOpen, ChevronDown, ChevronRight,
  Maximize2, Minimize2
} from 'lucide-react';
import Link from 'next/link';
import toast from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';

export default function CriteriaManagement() {
  const criteriaList = useLiveQuery(() => db.criteria.toArray()) || [];
  const [newMainTitle, setNewMainTitle] = useState('');
  const [newSubTitle, setNewSubTitle] = useState('');
  const [isAddingNewCategory, setIsAddingNewCategory] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  // Mevcut benzersiz ana kategorileri al
  const existingMainTitles = useMemo(() => {
    const titles = Array.from(new Set(criteriaList.map(c => c.mainTitle)));
    return titles.sort();
  }, [criteriaList]);

  // Kriterleri ana kategorilere göre grupla
  const groupedCriteria = useMemo(() => {
    return criteriaList.reduce((acc, curr) => {
      if (!acc[curr.mainTitle]) acc[curr.mainTitle] = [];
      acc[curr.mainTitle].push(curr);
      return acc;
    }, {} as Record<string, typeof criteriaList>);
  }, [criteriaList]);

  const toggleCategory = (title: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [title]: !prev[title]
    }));
  };

  const expandAll = () => {
    const all = {} as Record<string, boolean>;
    existingMainTitles.forEach(title => all[title] = true);
    setExpandedCategories(all);
  };

  const collapseAll = () => {
    setExpandedCategories({});
  };

  const handleAdd = async () => {
    if (!newMainTitle || !newSubTitle) {
      toast.error('Lütfen tüm alanları doldurun');
      return;
    }
    await db.criteria.add({
      id: crypto.randomUUID(),
      mainTitle: newMainTitle,
      subTitle: newSubTitle
    });
    setNewSubTitle('');
    // Yeni eklenen kriterin kategorisini otomatik aç
    setExpandedCategories(prev => ({ ...prev, [newMainTitle]: true }));
    toast.success('Kriter eklendi');
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Akordiyonu tetiklemesin
    if (confirm('Bu kriteri silmek istediğinize emin misiniz?')) {
      await db.criteria.delete(id);
      toast.success('Kriter silindi');
    }
  };

  return (
    <div className="p-4 space-y-6 animate-in fade-in slide-in-from-right-4 duration-500 pb-24 bg-gray-50 min-h-screen">
      <header className="pt-4 pb-2 flex items-center gap-3 border-b border-gray-200">
        <Link href="/settings">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Kriter Yönetimi</h1>
      </header>

      {/* Add New Criteria Form */}
      <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 space-y-5">
        <div className="flex items-center gap-2 text-blue-600">
          <FolderPlus className="w-5 h-5" />
          <h2 className="font-bold">Yeni Kriter Ekle</h2>
        </div>
        
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-semibold text-gray-500 uppercase">Ana Kategori</label>
              <button 
                onClick={() => {
                  setIsAddingNewCategory(!isAddingNewCategory);
                  setNewMainTitle('');
                }}
                className="text-xs font-bold text-blue-600 hover:underline"
              >
                {isAddingNewCategory ? 'Listeden Seç' : '+ Yeni Kategori Ekle'}
              </button>
            </div>
            
            {isAddingNewCategory ? (
              <motion.input 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                type="text" 
                value={newMainTitle}
                onChange={(e) => setNewMainTitle(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Yeni ana kategori adı girin"
                autoFocus
              />
            ) : (
              <select 
                value={newMainTitle}
                onChange={(e) => setNewMainTitle(e.target.value)}
                className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Kategori Seçin...</option>
                {existingMainTitles.map(title => (
                  <option key={title} value={title}>{title}</option>
                ))}
              </select>
            )}
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase">Alt Başlık / Kriter Açıklaması</label>
            <textarea 
              value={newSubTitle}
              onChange={(e) => setNewSubTitle(e.target.value)}
              className="w-full mt-1 p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 min-h-[80px]"
              placeholder="Denetim maddesi detayını girin"
            />
          </div>

          <button 
            onClick={handleAdd}
            disabled={!newMainTitle || !newSubTitle}
            className="w-full py-4 bg-blue-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-200"
          >
            <Plus className="w-5 h-5" />
            Kriteri Kaydet
          </button>
        </div>
      </div>

      {/* Existing Criteria List Grouped & Collapsible */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-gray-900">
            <LayoutGrid className="w-5 h-5 text-gray-500" />
            <h2 className="font-bold text-lg">Mevcut Kriterler</h2>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={expandAll}
              className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
              title="Tümünü Aç"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
            <button 
              onClick={collapseAll}
              className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
              title="Tümünü Kapat"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
            <span className="text-xs font-medium text-gray-500 bg-gray-200 px-2 py-1 rounded-full ml-1">
              {criteriaList.length}
            </span>
          </div>
        </div>

        <div className="space-y-3">
          {Object.entries(groupedCriteria).map(([mainTitle, items]) => {
            const isExpanded = expandedCategories[mainTitle];
            return (
              <div key={mainTitle} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <button 
                  onClick={() => toggleCategory(mainTitle)}
                  className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-1.5 rounded-lg ${isExpanded ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-500'}`}>
                      <FolderOpen className="w-4 h-4" />
                    </div>
                    <h3 className="font-bold text-gray-800 uppercase text-xs tracking-wider text-left">
                      {mainTitle}
                    </h3>
                    <span className="text-[10px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded-md font-bold">
                      {items.length}
                    </span>
                  </div>
                  {isExpanded ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronRight className="w-4 h-4 text-gray-400" />}
                </button>
                
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                      className="overflow-hidden"
                    >
                      <div className="p-4 pt-0 space-y-2 border-t border-gray-50">
                        {items.map(criteria => (
                          <div 
                            key={criteria.id} 
                            className="p-3 bg-gray-50/50 rounded-xl border border-transparent hover:border-blue-100 flex items-start justify-between group transition-all"
                          >
                            <div className="flex gap-2">
                              <ListTree className="w-3.5 h-3.5 text-gray-400 mt-1 flex-shrink-0" />
                              <p className="text-gray-700 text-sm leading-relaxed">
                                {criteria.subTitle}
                              </p>
                            </div>
                            <button 
                              onClick={(e) => handleDelete(criteria.id, e)}
                              className="p-1.5 text-gray-300 hover:text-red-500 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}

          {criteriaList.length === 0 && (
            <div className="text-center py-12 text-gray-400 bg-white rounded-3xl border border-dashed border-gray-200 flex flex-col items-center gap-3">
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center">
                <LayoutGrid className="w-8 h-8 text-gray-200" />
              </div>
              <p className="font-bold text-gray-500">Henüz kriter eklenmemiş</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
