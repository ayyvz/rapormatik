import { getServerSession } from 'next-auth';
import Link from 'next/link';
import { Settings as SettingsIcon, LogIn, LogOut, CheckSquare, Database, User, FileText } from 'lucide-react';

export default async function Settings() {
  const session = await getServerSession();

  return (
    <div className="p-4 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24 min-h-screen bg-gray-50">
      <header className="pt-4 pb-2">
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Ayarlar</h1>
      </header>

      {/* Account Section */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
            {session?.user?.image ? (
              <img src={session.user.image} alt="User" className="w-full h-full rounded-full" />
            ) : (
              <User className="w-6 h-6" />
            )}
          </div>
          <div>
            <h2 className="font-bold text-gray-900">
              {session?.user?.name || 'Giriş Yapılmadı'}
            </h2>
            <p className="text-sm text-gray-500">
              {session?.user?.email || 'Veri senkronizasyonu için giriş yapın'}
            </p>
          </div>
        </div>

        {session ? (
          <Link 
            href="/api/auth/signout"
            className="w-full py-3 bg-red-50 text-red-600 font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-red-100 transition"
          >
            <LogOut className="w-5 h-5" />
            Çıkış Yap
          </Link>
        ) : (
          <Link 
            href="/api/auth/signin/google"
            className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-blue-700 transition shadow-md"
          >
            <LogIn className="w-5 h-5" />
            Google ile Giriş Yap
          </Link>
        )}
      </div>

      {/* Management Links */}
      <div className="space-y-3">
        <Link href="/settings/criteria">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between active:scale-[0.98] transition-transform">
            <div className="flex items-center gap-3">
              <div className="bg-blue-50 p-2 rounded-lg text-blue-600">
                <CheckSquare className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">Kriter Yönetimi</h3>
                <p className="text-xs text-gray-500">Denetim maddelerini düzenleyin</p>
              </div>
            </div>
          </div>
        </Link>

        <Link href="/settings/sync">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between active:scale-[0.98] transition-transform">
            <div className="flex items-center gap-3">
              <div className="bg-green-50 p-2 rounded-lg text-green-600">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">Senkronizasyon</h3>
                <p className="text-xs text-gray-500">Google Drive & Sheets ayarları</p>
              </div>
            </div>
          </div>
        </Link>

        <Link href="/settings/data">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between active:scale-[0.98] transition-transform">
            <div className="flex items-center gap-3">
              <div className="bg-orange-50 p-2 rounded-lg text-orange-600">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">Veri Yönetimi</h3>
                <p className="text-xs text-gray-500">Verileri Yedekle & Geri Yükle</p>
              </div>
            </div>
          </div>
        </Link>
      </div>
    </div>
  );
}
