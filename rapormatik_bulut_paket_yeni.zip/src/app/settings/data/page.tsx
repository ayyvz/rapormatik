'use client';

import { db } from '@/lib/db/offline';
import Link from 'next/link';

export default function DataManagement() {
  return (
    <div style={{ padding: '20px', backgroundColor: '#fff', minHeight: '100vh' }}>
      
      {/* Harici JS dosyaları yüklenmese bile çalışacak satır içi kod */}
      <script dangerouslySetInnerHTML={{ __html: `
        function testCalistir() {
          alert("İNANILMAZ! Satır içi JavaScript çalışıyor. Şimdi verileri aktarabilirsiniz.");
        }
        
        async function veriyiAktar() {
          const area = document.getElementById('manual-textarea');
          if (!area.value) {
            alert("Lütfen önce metni yapıştırın!");
            return;
          }
          
          document.getElementById('import-status').innerText = "İŞLEM BAŞLADI, LÜTFEN BEKLEYİN...";
          
          try {
            // Not: db globalde olmadığı için burası hala ana JS'ye bağlıdır. 
            // Ama bu mesajı görüyorsanız ana JS de yüklenmiş demektir.
            window.dispatchEvent(new CustomEvent('do-import', { detail: area.value }));
          } catch(e) {
            alert("Hata: " + e.message);
          }
        }
      `}} />

      <button 
        onClick={() => {
          // Bu normal React eventidir
          alert("React Tıklaması Başarılı!");
        }}
        style={{ width: '100%', padding: '15px', backgroundColor: 'orange', color: '#000', border: 'none', borderRadius: '8px', fontWeight: 'bold', marginBottom: '20px' }}
      >
        TEST 1: REACT TIKLAMASI
      </button>

      <button 
        id="test-btn-inline"
        // @ts-ignore
        onClick="testCalistir()"
        className="native-click-test"
        style={{ width: '100%', padding: '15px', backgroundColor: 'cyan', color: '#000', border: 'none', borderRadius: '8px', fontWeight: 'bold', marginBottom: '20px' }}
      >
        TEST 2: SATIR İÇİ (INLINE) TIKLAMA
      </button>

      <div style={{ border: '2px solid #000', padding: '15px', borderRadius: '12px' }}>
        <h2 style={{ fontSize: '16px', marginBottom: '10px' }}>Veri Aktarımı</h2>
        <textarea 
          id="manual-textarea"
          style={{ width: '100%', minHeight: '250px', backgroundColor: '#eee', padding: '10px', boxSizing: 'border-box', marginBottom: '10px' }}
          placeholder="Yedek metnini buraya yapıştırın..."
        />
        <button 
          id="import-status"
          onClick={async (e) => {
            const btn = e.currentTarget;
            const val = (document.getElementById('manual-textarea') as HTMLTextAreaElement).value;
            if (!val) { alert("Metin boş!"); return; }
            
            btn.innerText = "YÜKLENİYOR...";
            try {
              const data = JSON.parse(val);
              await db.workplaces.bulkPut(data.workplaces || []);
              await db.criteria.bulkPut(data.criteria || []);
              await db.inspections.bulkPut(data.inspections || []);
              await db.inspectionResults.bulkPut(data.results || []);
              alert("BAŞARILI! Veriler yüklendi.");
              window.location.href = '/';
            } catch (err: any) {
              alert("HATA: " + err.message);
              btn.innerText = "TEKRAR DENE";
            }
          }}
          style={{ width: '100%', padding: '20px', backgroundColor: '#16a34a', color: '#fff', border: 'none', borderRadius: '12px', fontWeight: 'bold' }}
        >
          VERİLERİ ŞİMDİ YÜKLE
        </button>
      </div>
      
      <p style={{ marginTop: '20px', fontSize: '12px', color: '#666' }}>
        Eğer yukarıdaki Turuncu veya Mavi butonlara basınca mesaj çıkmıyorsa, telefonunuz bilgisayarınızdan gelen hiçbir kodu çalıştırmıyor demektir. Lütfen Firewall ayarlarınızı kontrol edin.
      </p>
    </div>
  );
}
