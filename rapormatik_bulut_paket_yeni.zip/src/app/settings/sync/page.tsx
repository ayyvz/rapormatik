'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { ChevronLeft, Save, FileSpreadsheet, HardDrive, CloudSync, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';
import { db } from '@/lib/db/offline';

export default function SyncSettings() {
  const [sheetId, setSheetId] = useState('');
  const [driveFolder, setDriveFolder] = useState('Rapormatik_Database');
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    // Load from local storage
    const savedSheetId = localStorage.getItem('google_sheet_id');
    const savedFolder = localStorage.getItem('google_drive_folder');
    if (savedSheetId) setSheetId(savedSheetId);
    if (savedFolder) setDriveFolder(savedFolder);
  }, []);

  const handleSave = () => {
    localStorage.setItem('google_sheet_id', sheetId);
    localStorage.setItem('google_drive_folder', driveFolder);
    toast.success('Ayarlar başarıyla kaydedildi!');
  };

  const handleCloudSync = async () => {
    setIsSyncing(true);
    const loadingToast = toast.loading('Bulutla senkronize ediliyor...');

    try {
      // 1. Get all local data
      const workplaces = await db.workplaces.toArray();
      const inspections = await db.inspections.toArray();
      const criteria = await db.criteria.toArray();
      const results = await db.inspectionResults.toArray();

      const localData = {
        workplaces,
        inspections,
        criteria,
        results
      };

      // 2. Push to server/drive
      const res = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(localData)
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || 'Senkronizasyon hatası');
      }

      const { data: mergedData } = await res.json();

      // 3. Update local DB with merged data
      if (mergedData) {
        await db.transaction('rw', [db.workplaces, db.inspections, db.criteria, db.inspectionResults], async () => {
          if (mergedData.workplaces) await db.workplaces.bulkPut(mergedData.workplaces);
          if (mergedData.inspections) await db.inspections.bulkPut(mergedData.inspections);
          if (mergedData.criteria) await db.criteria.bulkPut(mergedData.criteria);
          if (mergedData.results) await db.inspectionResults.bulkPut(mergedData.results);
        });
      }

      toast.success('Senkronizasyon başarıyla tamamlandı!', { id: loadingToast });
    } catch (error: any) {
      console.error('Cloud sync error:', error);
      toast.error(`Hata: ${error.message}`, { id: loadingToast });
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="p-4 space-y-6 animate-in fade-in slide-in-from-right-4 duration-500 pb-24 min-h-screen bg-gray-50">
      <header className="pt-4 pb-2 flex items-center gap-3 border-b border-gray-200">
        <Link href="/settings">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Senkronizasyon</h1>
      </header>

      <div className="bg-blue-50 text-blue-800 p-4 rounded-xl text-sm border border-blue-100">
        Bu ayarlar kullanılarak verileriniz Google Workspace hesabınıza yedeklenecektir. Bu işlemin çalışması için ana ayarlar menüsünden Google ile giriş yapmış olmalısınız.
      </div>

      <div className="space-y-4">
        {/* Cloud Sync Section */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-blue-100 p-2 rounded-lg text-blue-600">
              <CloudSync className="w-5 h-5" />
            </div>
            <h2 className="font-bold text-gray-900">Bulut Senkronizasyonu</h2>
          </div>
          
          <p className="text-xs text-gray-500 mb-4">
            Tüm cihazlardaki verilerinizi Google Drive üzerinden birleştirin ve yedekleyin.
          </p>

          <button 
            onClick={handleCloudSync}
            disabled={isSyncing}
            className="w-full py-4 bg-blue-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-blue-700 transition shadow-lg active:scale-95 disabled:opacity-50"
          >
            {isSyncing ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <CloudSync className="w-5 h-5" />
            )}
            {isSyncing ? 'Senkronize Ediliyor...' : 'Bulutla Senkronize Et'}
          </button>
        </div>

        {/* Google Drive Settings */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-orange-100 p-2 rounded-lg text-orange-600">
              <HardDrive className="w-5 h-5" />
            </div>
            <h2 className="font-bold text-gray-900">Google Drive Ayarları</h2>
          </div>
          
          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-500 uppercase">Drive Klasör Adı</label>
            <input 
              type="text" 
              value={driveFolder}
              onChange={(e) => setDriveFolder(e.target.value)}
              placeholder="Örn: Rapormatik_Database"
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            />
            <p className="text-xs text-gray-400">Veritabanı yedeğiniz bu klasör altında saklanacaktır.</p>
          </div>
        </div>

        {/* Google Sheets Settings */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-green-100 p-2 rounded-lg text-green-600">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <h2 className="font-bold text-gray-900">Google Sheets Veritabanı</h2>
          </div>
          
          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-500 uppercase">Spreadsheet ID</label>
            <input 
              type="text" 
              value={sheetId}
              onChange={(e) => setSheetId(e.target.value)}
              placeholder="Örn: 1BxiMVs0XRY..."
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-green-500 text-sm"
            />
            <p className="text-xs text-gray-400">Raporların aktarılacağı Google E-Tablo ID'si.</p>
          </div>
        </div>

        <button 
          onClick={handleSave}
          className="w-full py-4 bg-gray-900 text-white font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-gray-800 transition shadow-lg active:scale-95"
        >
          <Save className="w-5 h-5" />
          Ayarları Kaydet
        </button>
      </div>
    </div>
  );
}
