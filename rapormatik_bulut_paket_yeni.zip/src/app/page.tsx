'use client';

import { useState, useEffect } from 'react';
import { db } from '@/lib/db/offline';
import Link from 'next/link';
import { Building2, ClipboardCheck, CalendarDays, Settings, ChevronRight, Activity, TrendingUp } from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';

export default function Home() {
  const [log, setLog] = useState('Hazırlanıyor...');
  const [data, setData] = useState({ workplaces: 0, inspections: 0, criteria: 0 });
  const [step, setStep] = useState(0);

  const loadData = async () => {
    try {
      setStep(1);
      setLog('Bağlantı kuruluyor...');
      
      if (!db.isOpen()) {
        await db.open();
      }

      setStep(2);
      setLog('Veriler yükleniyor...');
      const wCount = await db.workplaces.count();
      const iCount = await db.inspections.count();
      const cCount = await db.criteria.count();

      setStep(3);
      setData({ workplaces: wCount, inspections: iCount, criteria: cCount });
      setLog('Sistem Aktif');
    } catch (e: any) {
      setLog('Hata: ' + e.message);
      console.error(e);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50/50 pb-24">
      {/* Premium Header */}
      <div className="bg-blue-600 px-6 pt-12 pb-20 rounded-b-[40px] shadow-lg shadow-blue-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500 rounded-full -mr-20 -mt-20 opacity-20 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-400 rounded-full -ml-20 -mb-20 opacity-20 blur-3xl"></div>
        
        <div className="relative">
          <div className="flex justify-between items-center mb-6">
            <div>
              <p className="text-blue-100 text-sm font-medium mb-1">{format(new Date(), 'dd MMMM yyyy, EEEE', { locale: tr })}</p>
              <h1 className="text-3xl font-extrabold text-white tracking-tight">Rapormatik</h1>
            </div>
            <div className="bg-white/20 p-2 rounded-2xl backdrop-blur-md">
              <Activity className="w-6 h-6 text-white" />
            </div>
          </div>
          
          <div className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full border border-white/20 backdrop-blur-sm">
            <div className={`w-2 h-2 rounded-full ${step === 3 ? 'bg-green-400 animate-pulse' : 'bg-yellow-400'}`}></div>
            <span className="text-xs font-bold text-white uppercase tracking-widest">{log}</span>
          </div>
        </div>
      </div>

      <div className="px-6 -mt-12 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center justify-center group hover:border-blue-200 transition-all active:scale-95">
            <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-3 group-hover:scale-110 transition-transform">
              <Building2 className="w-6 h-6" />
            </div>
            <div className="text-3xl font-black text-gray-900 leading-none">{data.workplaces}</div>
            <div className="text-[10px] font-bold text-gray-400 uppercase mt-2 tracking-widest">İşletme</div>
          </div>
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center justify-center group hover:border-green-200 transition-all active:scale-95">
            <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-600 mb-3 group-hover:scale-110 transition-transform">
              <ClipboardCheck className="w-6 h-6" />
            </div>
            <div className="text-3xl font-black text-gray-900 leading-none">{data.inspections}</div>
            <div className="text-[10px] font-bold text-gray-400 uppercase mt-2 tracking-widest">Denetim</div>
          </div>
        </div>

        {/* Quick Actions Title */}
        <div className="flex items-center justify-between px-2">
          <h2 className="text-lg font-black text-gray-900 tracking-tight">Hızlı Erişim</h2>
          <TrendingUp className="w-4 h-4 text-blue-500" />
        </div>

        {/* Action Cards */}
        <div className="grid grid-cols-1 gap-3">
          <Link href="/calendar" className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between group active:scale-[0.98] transition-all">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-500 group-hover:bg-amber-100 transition-colors">
                <CalendarDays className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">Takvim & Planlama</h3>
                <p className="text-xs text-gray-500 font-medium">Gidilecek yerleri takip et</p>
              </div>
            </div>
            <div className="bg-gray-50 p-2 rounded-xl text-gray-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-all">
              <ChevronRight className="w-5 h-5" />
            </div>
          </Link>

          <Link href="/workplaces" className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between group active:scale-[0.98] transition-all">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 group-hover:bg-blue-100 transition-colors">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">İşletme Yönetimi</h3>
                <p className="text-xs text-gray-500 font-medium">İşletmeleri listele ve ekle</p>
              </div>
            </div>
            <div className="bg-gray-50 p-2 rounded-xl text-gray-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-all">
              <ChevronRight className="w-5 h-5" />
            </div>
          </Link>

          <Link href="/settings" className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between group active:scale-[0.98] transition-all">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-500 group-hover:bg-gray-100 transition-colors">
                <Settings className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">Sistem Ayarları</h3>
                <p className="text-xs text-gray-500 font-medium">Veri senkronizasyonu ve tercihler</p>
              </div>
            </div>
            <div className="bg-gray-50 p-2 rounded-xl text-gray-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-all">
              <ChevronRight className="w-5 h-5" />
            </div>
          </Link>
        </div>

        {/* Info Card */}
        <div className="bg-blue-50 p-6 rounded-[32px] border border-blue-100 relative overflow-hidden">
          <div className="relative z-10">
            <h4 className="text-blue-900 font-black text-sm mb-2 flex items-center gap-2">
              <ClipboardCheck className="w-4 h-4" />
              Önemli Bilgi
            </h4>
            <p className="text-blue-700/80 text-xs leading-relaxed font-medium">
              Eğer verileriniz 0 görünüyorsa, Ayarlar sayfasından veri senkronizasyonunu kontrol edin veya manuel yedek yükleyin.
            </p>
          </div>
          <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-blue-100 rounded-full opacity-50"></div>
        </div>
      </div>
    </div>
  );
}
