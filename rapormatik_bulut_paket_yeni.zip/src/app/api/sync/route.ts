import { NextRequest, NextResponse } from 'next/server';
import { google } from 'googleapis';
import { getServerSession } from 'next-auth';
import fs from 'fs';
import path from 'path';
import { mergeSyncData, SyncData } from '@/lib/sync-utils';

const DATA_FILE = path.join(process.cwd(), 'data_sync.json');
const SYNC_FILENAME = 'data_sync.json';
const FOLDER_NAME = 'Rapormatik_Database';

async function getDriveClient(req?: NextRequest) {
  let accessToken = null;

  // 1. Check for Authorization header (for legacy index.html support)
  if (req) {
    const authHeader = req.headers.get('Authorization');
    if (authHeader && authHeader.startsWith('Bearer ')) {
      accessToken = authHeader.substring(7);
    }
  }

  // 2. Check for session (for Next.js App Router UI)
  if (!accessToken) {
    const session = await getServerSession();
    // @ts-ignore
    accessToken = session?.accessToken;
  }

  if (!accessToken) return null;

  const auth = new google.auth.OAuth2();
  auth.setCredentials({ access_token: accessToken });
  return google.drive({ version: 'v3', auth });
}

async function getOrCreateFolder(drive: any, folderName: string) {
  const res = await drive.files.list({
    q: `mimeType='application/vnd.google-apps.folder' and name='${folderName}' and trashed=false`,
    fields: 'files(id, name)',
  });

  if (res.data.files && res.data.files.length > 0) {
    return res.data.files[0].id;
  }

  const newFolder = await drive.files.create({
    requestBody: {
      name: folderName,
      mimeType: 'application/vnd.google-apps.folder',
    },
    fields: 'id',
  });
  return newFolder.data.id;
}

async function getDriveFileData(drive: any) {
  try {
    const res = await drive.files.list({
      q: `name='${SYNC_FILENAME}' and trashed=false`,
      fields: 'files(id, name)',
    });

    if (!res.data.files || res.data.files.length === 0) return null;

    const fileId = res.data.files[0].id;
    const fileContent = await drive.files.get({
      fileId: fileId,
      alt: 'media',
    });

    return { id: fileId, data: fileContent.data as SyncData };
  } catch (error) {
    console.error('Error fetching file from Drive:', error);
    return null;
  }
}

export async function GET(req: NextRequest) {
  try {
    const drive = await getDriveClient(req);
    
    if (drive) {
      const driveFile = await getDriveFileData(drive);
      if (driveFile) {
        // Cache locally too
        fs.writeFileSync(DATA_FILE, JSON.stringify(driveFile.data, null, 2));
        return NextResponse.json(driveFile.data);
      }
    }

    // Fallback to local if no drive or file not found
    if (!fs.existsSync(DATA_FILE)) {
      return NextResponse.json({ workplaces: [], inspections: [], criteria: [], results: [] });
    }
    const data = fs.readFileSync(DATA_FILE, 'utf8');
    return NextResponse.json(JSON.parse(data));
  } catch (error: any) {
    console.error('Sync GET error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const clientData = await req.json();
    const drive = await getDriveClient(req);

    let finalData = clientData;

    if (drive) {
      // 1. Get current data from Drive
      const driveFile = await getDriveFileData(drive);
      
      // 2. Merge
      if (driveFile) {
        finalData = mergeSyncData(driveFile.data, clientData);
        
        // 3. Update existing file
        const { Readable } = require('stream');
        const stream = new Readable();
        stream.push(JSON.stringify(finalData, null, 2));
        stream.push(null);

        await drive.files.update({
          fileId: driveFile.id,
          media: {
            mimeType: 'application/json',
            body: stream,
          },
        });
      } else {
        // 3. Create new file if doesn't exist
        const folderId = await getOrCreateFolder(drive, FOLDER_NAME);
        const { Readable } = require('stream');
        const stream = new Readable();
        stream.push(JSON.stringify(finalData, null, 2));
        stream.push(null);

        await drive.files.create({
          requestBody: {
            name: SYNC_FILENAME,
            parents: [folderId],
          },
          media: {
            mimeType: 'application/json',
            body: stream,
          },
        });
      }
    }

    // Always cache locally as well
    fs.writeFileSync(DATA_FILE, JSON.stringify(finalData, null, 2));

    return NextResponse.json({ success: true, data: finalData });
  } catch (error: any) {
    console.error('Sync POST error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
