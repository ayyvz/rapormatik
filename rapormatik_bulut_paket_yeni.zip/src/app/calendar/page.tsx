'use client';

import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/lib/db/offline';
import Link from 'next/link';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, isToday } from 'date-fns';
import { tr } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Clock, CheckCircle, AlertTriangle, MapPin, Building2, Calendar as CalendarIcon, PlusCircle } from 'lucide-react';

export default function CalendarPage() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  const inspections = useLiveQuery(() => db.inspections.toArray()) || [];
  const workplaces = useLiveQuery(() => db.workplaces.toArray()) || [];

  const days = eachDayOfInterval({
    start: startOfMonth(currentMonth),
    end: endOfMonth(currentMonth)
  });

  const getDayInspections = (date: Date) => {
    return inspections.filter(i => isSameDay(new Date(i.date), date));
  };

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));

  const selectedDayInspections = getDayInspections(selectedDate);

  return (
    <div className="min-h-screen bg-gray-50/50 pb-24 animate-in fade-in duration-500">
      {/* Header */}
      <div className="bg-white px-6 pt-12 pb-6 rounded-b-[40px] shadow-sm border-b border-gray-100">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-black text-gray-900 tracking-tight">Takvim</h1>
            <p className="text-sm text-gray-500 font-medium">{format(currentMonth, 'MMMM yyyy', { locale: tr })}</p>
          </div>
          <div className="flex gap-2">
            <button onClick={prevMonth} className="p-3 bg-gray-50 hover:bg-gray-100 rounded-2xl transition-colors text-gray-600">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button onClick={nextMonth} className="p-3 bg-gray-50 hover:bg-gray-100 rounded-2xl transition-colors text-gray-600">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Calendar Grid */}
        <div className="bg-white rounded-[32px] p-6 shadow-sm border border-gray-100">
          <div className="grid grid-cols-7 gap-1 text-center mb-4">
            {['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'].map(day => (
              <div key={day} className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{day}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {days.map((day) => {
              const dayInspections = getDayInspections(day);
              const isSelected = isSameDay(day, selectedDate);
              const today = isToday(day);
              
              // Determine background color based on inspections
              let bgColor = 'bg-transparent';
              let textColor = 'text-gray-700';
              let ringColor = '';

              if (dayInspections.length > 0) {
                const hasCompleted = dayInspections.some(i => i.status === 'Completed' || i.status === 'finished');
                const hasPlanned = dayInspections.some(i => i.status === 'Planned' || i.status === 'started');
                
                if (hasCompleted) {
                  bgColor = 'bg-green-500';
                  textColor = 'text-white font-bold';
                } else if (hasPlanned) {
                  bgColor = 'bg-amber-400';
                  textColor = 'text-white font-bold';
                } else {
                  bgColor = 'bg-red-500';
                  textColor = 'text-white font-bold';
                }
              }

              if (isSelected) {
                ringColor = 'ring-4 ring-blue-100 border-2 border-blue-500';
                if (bgColor === 'bg-transparent') {
                  bgColor = 'bg-blue-600';
                  textColor = 'text-white font-bold';
                }
              } else if (today) {
                ringColor = 'border-2 border-blue-200';
              }

              return (
                <button 
                  key={day.toString()} 
                  onClick={() => setSelectedDate(day)}
                  className={`aspect-square flex flex-col items-center justify-center rounded-2xl transition-all relative ${bgColor} ${textColor} ${ringColor} active:scale-90`}
                >
                  <span className="text-sm">{format(day, 'd')}</span>
                  {today && !isSelected && <div className="absolute bottom-1 w-1 h-1 bg-blue-500 rounded-full"></div>}
                </button>
              );
            })}
          </div>
          
          {/* Legend */}
          <div className="mt-6 flex flex-wrap gap-4 pt-6 border-t border-gray-50">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full shadow-sm shadow-green-100"></div>
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-tighter">Tamamlandı</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-amber-400 rounded-full shadow-sm shadow-amber-100"></div>
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-tighter">Planlandı</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-600 rounded-full shadow-sm shadow-blue-100"></div>
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-tighter">Seçili</span>
            </div>
          </div>
        </div>

        {/* Day Details */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="font-black text-gray-900 tracking-tight flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-blue-500" />
              {format(selectedDate, 'dd MMMM', { locale: tr })} Detayları
            </h3>
            <span className="bg-gray-100 text-gray-500 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
              {selectedDayInspections.length} Kayıt
            </span>
          </div>

          <div className="space-y-3">
            {selectedDayInspections.map((inspection) => {
              const workplace = workplaces.find(w => w.id === inspection.workplaceId);
              const isDone = inspection.status === 'Completed' || inspection.status === 'finished';
              const isPlanned = inspection.status === 'Planned' || inspection.status === 'started';
              
              return (
                <Link key={inspection.id} href={`/inspections/${inspection.id}`}>
                  <div className="bg-white border border-gray-100 p-5 rounded-[28px] shadow-sm flex items-center justify-between active:scale-[0.98] transition-transform group">
                    <div className="flex items-center gap-4">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-inner ${
                        isDone ? 'bg-green-50 text-green-500 border border-green-100' :
                        isPlanned ? 'bg-amber-50 text-amber-500 border border-amber-100' : 'bg-red-50 text-red-500 border border-red-100'
                      }`}>
                        {isDone ? <CheckCircle className="w-7 h-7" /> :
                         isPlanned ? <Clock className="w-7 h-7" /> : <AlertTriangle className="w-7 h-7" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-black text-gray-900 truncate group-hover:text-blue-600 transition-colors">{workplace?.name || 'Bilinmeyen İşletme'}</h4>
                        <div className="flex items-center gap-3 mt-1">
                          <div className="flex items-center text-[10px] text-gray-400 font-bold uppercase tracking-tight">
                            <MapPin className="w-3 h-3 mr-1" />
                            {workplace?.address ? (workplace.address.length > 20 ? workplace.address.substring(0, 20) + '...' : workplace.address) : 'Adres yok'}
                          </div>
                          <div className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md ${
                            isDone ? 'bg-green-100 text-green-700' :
                            isPlanned ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'
                          }`}>
                            {isDone ? 'TAMAM' : isPlanned ? 'BEKLEYEN' : 'DİKKAT'}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="bg-gray-50 p-2 rounded-xl text-gray-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-all">
                      <ChevronRight className="w-5 h-5" />
                    </div>
                  </div>
                </Link>
              );
            })}
            
            {selectedDayInspections.length === 0 && (
              <div className="text-center py-12 bg-white rounded-[32px] border border-dashed border-gray-200 flex flex-col items-center gap-4">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center text-gray-300">
                  <Building2 className="w-8 h-8" />
                </div>
                <div>
                  <p className="font-black text-gray-400 text-sm tracking-tight uppercase">Bu gün için kayıt bulunmuyor</p>
                  <p className="text-xs text-gray-300 font-medium mt-1 mb-4">Yeni bir denetim planlamak için butona dokunabilirsin</p>
                  <Link 
                    href={`/inspections/new?date=${selectedDate.toISOString()}`}
                    className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-2xl font-bold text-sm shadow-lg shadow-blue-100 active:scale-95 transition-all"
                  >
                    <PlusCircle className="w-4 h-4" />
                    Denetim Planla
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
