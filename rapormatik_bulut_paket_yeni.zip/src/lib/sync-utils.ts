export interface SyncData {
  workplaces: any[];
  inspections: any[];
  criteria: any[];
  results: any[];
  updatedAt?: string;
}

export function mergeSyncData(oldData: SyncData, newData: SyncData): SyncData {
  const mergeArray = (oldArr: any[] = [], newArr: any[] = []) => {
    const map = new Map();
    // Use ID as key to merge. New items overwrite old ones if IDs match.
    // However, for certain items we might want to keep the one with a more recent 'updatedAt' if available.
    // For simplicity now, we just merge by ID.
    [...oldArr, ...newArr].forEach(item => {
      if (item && item.id) {
        map.set(item.id, { ...(map.get(item.id) || {}), ...item });
      }
    });
    return Array.from(map.values());
  };

  return {
    workplaces: mergeArray(oldData.workplaces, newData.workplaces),
    inspections: mergeArray(oldData.inspections, newData.inspections),
    criteria: mergeArray(oldData.criteria, newData.criteria),
    results: mergeArray(oldData.results, newData.results),
    updatedAt: new Date().toISOString()
  };
}
