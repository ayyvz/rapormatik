import Dexie, { Table } from 'dexie';

export interface Workplace {
  id: string;
  name: string;
  address: string;
  authorizedPerson: string;
  phone: string;
  synced: boolean;
}

export interface Inspection {
  id: string;
  workplaceId: string;
  date: string;
  status: 'Planned' | 'Completed' | 'Follow-up Required';
  inspector: string;
  nextDate?: string;
  synced: boolean;
}

export interface Criteria {
  id: string;
  mainTitle: string;
  subTitle: string;
}

export interface InspectionResult {
  id: string;
  inspectionId: string;
  criteriaId: string;
  status: 'OK' | 'Needs Improvement' | 'Not Compliant';
  notes: string;
  photos: string[]; // Base64 or local blob URLs
  resolved?: boolean;
}

export class RapormatikDB extends Dexie {
  workplaces!: Table<Workplace>;
  inspections!: Table<Inspection>;
  criteria!: Table<Criteria>;
  inspectionResults!: Table<InspectionResult>;

  constructor() {
    super('RapormatikDB');
    this.version(1).stores({
      workplaces: 'id, name, synced',
      inspections: 'id, workplaceId, date, status, synced',
      criteria: 'id, mainTitle',
      inspectionResults: 'id, inspectionId, criteriaId'
    });
  }
}

export const db = new RapormatikDB();
