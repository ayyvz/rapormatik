import type { NextConfig } from "next";

const withPWA = require('next-pwa')({
  dest: 'public',
  disable: process.env.NODE_ENV === 'development',
  register: true,
  skipWaiting: true,
});

const nextConfig: NextConfig = {
  turbopack: {},
  allowedDevOrigins: ['http://192.168.1.179:3000', '192.168.1.179', 'http://192.168.1.179'],
};

export default withPWA(nextConfig);
