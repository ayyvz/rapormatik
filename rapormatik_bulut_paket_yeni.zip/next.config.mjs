/** @type {import('next').NextConfig} */
const nextConfig = {
  // Build sırasında ESLint hatalarını görmezden gel
  eslint: {
    ignoreDuringBuilds: true,
  },
  // Build sırasında TypeScript hatalarını görmezden gel
  typescript: {
    ignoreBuildErrors: true,
  },
};

export default nextConfig;
